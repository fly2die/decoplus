/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import com.mojang.realmsclient.dto.ReflectionBasedSerialization;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public record RealmTierConfigurationDto(@SerializedName(value="renderDistance") RealmTierRangeDto renderDistance, @SerializedName(value="simDistance") RealmTierRangeDto simDistance) implements ReflectionBasedSerialization
{
    @SerializedName(value="renderDistance")
    public RealmTierRangeDto renderDistance() {
        return this.renderDistance;
    }

    @SerializedName(value="simDistance")
    public RealmTierRangeDto simDistance() {
        return this.simDistance;
    }

    @Environment(value=EnvType.CLIENT)
    public record RealmTierRangeDto(@SerializedName(value="min") int min, @SerializedName(value="max") int max, @SerializedName(value="defaultValue") int defaultValue, @SerializedName(value="current") @Nullable Integer current) implements ReflectionBasedSerialization
    {
        @SerializedName(value="min")
        public int min() {
            return this.min;
        }

        @SerializedName(value="max")
        public int max() {
            return this.max;
        }

        @SerializedName(value="defaultValue")
        public int defaultValue() {
            return this.defaultValue;
        }

        @SerializedName(value="current")
        public @Nullable Integer current() {
            return this.current;
        }
    }
}

