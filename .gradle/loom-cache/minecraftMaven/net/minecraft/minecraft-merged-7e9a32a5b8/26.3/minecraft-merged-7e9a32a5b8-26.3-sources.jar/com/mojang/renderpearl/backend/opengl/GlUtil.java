/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.backend.opengl;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class GlUtil {
    public static int selectBufferBindTarget(@GpuBuffer.Usage int usage) {
        if ((usage & 0x20) != 0) {
            return 34962;
        }
        if ((usage & 0x40) != 0) {
            return 34963;
        }
        if ((usage & 0x80) != 0) {
            return 35345;
        }
        if ((usage & 0x200) != 0) {
            return 36671;
        }
        return 36663;
    }
}

