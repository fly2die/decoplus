/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.frontend.shaders;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.jtracy.TracyClient;
import com.mojang.jtracy.Zone;
import com.mojang.renderpearl.api.pipeline.ShaderSource;
import com.mojang.renderpearl.api.pipeline.ShaderType;
import com.mojang.renderpearl.backend.api.SpvModule;
import com.mojang.renderpearl.frontend.shaders.SPIRVModule;
import com.mojang.renderpearl.util.ShaderCompileException;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import java.nio.ByteBuffer;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.ShaderDefines;
import net.minecraft.resources.Identifier;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.shaderc.Shaderc;
import org.lwjgl.util.shaderc.ShadercIncludeResolve;
import org.lwjgl.util.shaderc.ShadercIncludeResultRelease;

@Environment(value=EnvType.CLIENT)
public class GlslCompiler
implements UncheckedAutoCloseable {
    private final boolean isZeroToOne;
    private final boolean shaderDrawParameters;
    private final ShadercIncludeResultRelease includeResultRelease;
    private final ShaderSource.CachedIncludeSource missingIncludeResult;
    private final ShaderSource.CachedIncludeSource malformedIdResult;
    private final LongArrayList compilers = new LongArrayList();

    public GlslCompiler(boolean isZeroToOne, boolean shaderDrawParameters) {
        this.isZeroToOne = isZeroToOne;
        this.shaderDrawParameters = shaderDrawParameters;
        this.includeResultRelease = ShadercIncludeResultRelease.create(GlslCompiler::releaseIncludeResult);
        this.missingIncludeResult = ShaderSource.CachedIncludeSource.createError("not found");
        this.malformedIdResult = ShaderSource.CachedIncludeSource.createError("malformed id");
    }

    private ShaderSource.CachedIncludeSource processInclude(ShaderSource shaderSource, String requestedShader) {
        Identifier id = Identifier.tryParse(requestedShader);
        if (id == null) {
            return this.malformedIdResult;
        }
        ShaderSource.CachedIncludeSource shaderContents = shaderSource.getInclude(id);
        if (shaderContents == null) {
            return this.missingIncludeResult;
        }
        return shaderContents;
    }

    private ShadercIncludeResolve createIncludeResolver(ShaderSource shaderSource) {
        return ShadercIncludeResolve.create((l, requested_source, n, l2, l3) -> {
            String requestedShader = MemoryUtil.memASCII(requested_source);
            return this.processInclude(shaderSource, requestedShader).includeResultPtr();
        });
    }

    private static void releaseIncludeResult(long user_data, long include_result) {
    }

    @Override
    public void close() {
        this.includeResultRelease.close();
        this.malformedIdResult.close();
        this.missingIncludeResult.close();
        this.compilers.forEach(Shaderc::shaderc_compiler_release);
        this.compilers.clear();
    }

    private synchronized long acquireCompiler() {
        if (this.compilers.isEmpty()) {
            return Shaderc.shaderc_compiler_initialize();
        }
        return this.compilers.popLong();
    }

    private synchronized void releaseCompiler(long compiler) {
        this.compilers.add(compiler);
    }

    private long createBaseShaderOptions() {
        long shaderOptions = Shaderc.shaderc_compile_options_initialize();
        Shaderc.shaderc_compile_options_set_target_env(shaderOptions, 0, 0x402000);
        Shaderc.shaderc_compile_options_set_auto_bind_uniforms(shaderOptions, true);
        Shaderc.shaderc_compile_options_set_preserve_bindings(shaderOptions, false);
        Shaderc.shaderc_compile_options_set_generate_debug_info(shaderOptions);
        Shaderc.shaderc_compile_options_set_optimization_level(shaderOptions, 0);
        if (this.isZeroToOne) {
            Shaderc.shaderc_compile_options_add_macro_definition(shaderOptions, "RENDERPEARL_DEPTH_IS_ZERO_TO_ONE", "");
        }
        if (RenderSystem.getDevice().getDeviceInfo().hintsAndWorkarounds().isExplicitDepthRequired()) {
            Shaderc.shaderc_compile_options_add_macro_definition(shaderOptions, "RENDERPEARL_EXPLICIT_DEPTH_INVARIANCE", "");
        }
        if (this.shaderDrawParameters) {
            Shaderc.shaderc_compile_options_add_macro_definition(shaderOptions, "RENDERPEARL_INSTANCE_INDEX_INCLUDES_BASE_INSTANCE", "");
        }
        return shaderOptions;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public SpvModule compileToSpv(String name, String source, ShaderType type, ShaderDefines shaderDefines, ShaderSource shaderSource) throws ShaderCompileException {
        int shaderType = type == ShaderType.FRAGMENT ? 1 : 0;
        ByteBuffer sourceBuffer = MemoryUtil.memUTF8(source, false);
        ByteBuffer filenameBuffer = MemoryUtil.memUTF8(name);
        ByteBuffer entrypointBuffer = MemoryUtil.memUTF8("main");
        long shaderOptions = this.createBaseShaderOptions();
        for (Map.Entry<String, String> macro : shaderDefines.values().entrySet()) {
            Shaderc.shaderc_compile_options_add_macro_definition(shaderOptions, macro.getKey(), macro.getValue());
        }
        for (String flag : shaderDefines.flags()) {
            Shaderc.shaderc_compile_options_add_macro_definition(shaderOptions, flag, "");
        }
        try (ShadercIncludeResolve includeResolver = this.createIncludeResolver(shaderSource);){
            SPIRVModule sPIRVModule;
            long result;
            Shaderc.shaderc_compile_options_set_include_callbacks(shaderOptions, includeResolver, this.includeResultRelease, 0L);
            long compiler = this.acquireCompiler();
            try (Zone tracyZone = TracyClient.beginZone("Compile to SPV", false);){
                tracyZone.addText(name);
                result = Shaderc.shaderc_compile_into_spv(compiler, sourceBuffer, shaderType, filenameBuffer, entrypointBuffer, shaderOptions);
            } finally {
                this.releaseCompiler(compiler);
            }
            try {
                int status = Shaderc.shaderc_result_get_compilation_status(result);
                if (status != 0) {
                    throw new ShaderCompileException("Couldn't parse GLSL: " + Shaderc.shaderc_result_get_error_message(result));
                }
                ByteBuffer spirv = Shaderc.shaderc_result_get_bytes(result);
                ByteBuffer copy = MemoryUtil.memCalloc(spirv.remaining());
                MemoryUtil.memCopy(spirv, copy);
                sPIRVModule = new SPIRVModule(copy, type);
            } catch (Throwable throwable) {
                Shaderc.shaderc_result_release(result);
                Shaderc.shaderc_compile_options_release(shaderOptions);
                MemoryUtil.memFree(entrypointBuffer);
                MemoryUtil.memFree(filenameBuffer);
                MemoryUtil.memFree(sourceBuffer);
                throw throwable;
            }
            Shaderc.shaderc_result_release(result);
            Shaderc.shaderc_compile_options_release(shaderOptions);
            MemoryUtil.memFree(entrypointBuffer);
            MemoryUtil.memFree(filenameBuffer);
            MemoryUtil.memFree(sourceBuffer);
            return sPIRVModule;
        }
    }
}

