/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.pipeline;

import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public interface CompiledRenderPipeline
extends UncheckedAutoCloseable {
    public boolean isClosed();

    @FunctionalInterface
    @Environment(value=EnvType.CLIENT)
    public static interface Pending {
        public static final Pending NULL = () -> null;

        public @Nullable CompiledRenderPipeline finishCompile();
    }
}

