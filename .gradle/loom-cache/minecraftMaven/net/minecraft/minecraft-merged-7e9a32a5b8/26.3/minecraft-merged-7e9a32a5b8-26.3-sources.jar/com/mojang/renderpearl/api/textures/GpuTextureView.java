/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.api.textures;

import com.mojang.renderpearl.api.textures.GpuTexture;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface GpuTextureView
extends UncheckedAutoCloseable {
    public boolean isClosed();

    public GpuTexture texture();

    public int baseMipLevel();

    public int mipLevels();

    public int getWidth(int var1);

    public int getHeight(int var1);
}

