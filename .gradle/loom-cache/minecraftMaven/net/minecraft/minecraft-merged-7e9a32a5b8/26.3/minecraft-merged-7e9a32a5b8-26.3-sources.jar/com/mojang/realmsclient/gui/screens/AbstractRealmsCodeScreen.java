/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.realmsclient.gui.screens;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.resources.Identifier;

@Environment(value=EnvType.CLIENT)
public abstract class AbstractRealmsCodeScreen
extends RealmsScreen {
    private static final Identifier MENU_LIST_BACKGROUND = Identifier.withDefaultNamespace("textures/gui/menu_list_background.png");
    protected final HeaderAndFooterLayout layout = new HeaderAndFooterLayout(this);

    protected AbstractRealmsCodeScreen(Component title) {
        super(title);
    }

    @Override
    protected void repositionElements() {
        this.layout.arrangeElements();
    }

    @Override
    protected void extractMenuBackground(GuiGraphicsExtractor graphics) {
        super.extractMenuBackground(graphics, 0, 0, this.width, this.height);
        if (this.shouldRenderListBackgroundAndSeparators()) {
            graphics.blit(RenderPipelines.GUI_TEXTURED, MENU_LIST_BACKGROUND, 0, this.layout.getHeaderHeight(), 0.0f, 0.0f, this.width, this.layout.getContentHeight(), 32, 32);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
        super.extractRenderState(graphics, mouseX, mouseY, a);
        if (this.shouldRenderListBackgroundAndSeparators()) {
            graphics.blit(RenderPipelines.GUI_TEXTURED, Screen.HEADER_SEPARATOR, 0, this.layout.getHeaderHeight() - 2, 0.0f, 0.0f, this.width, 2, 32, 2);
            graphics.blit(RenderPipelines.GUI_TEXTURED, Screen.FOOTER_SEPARATOR, 0, this.height - this.layout.getFooterHeight(), 0.0f, 0.0f, this.width, 2, 32, 2);
        }
    }

    protected boolean shouldRenderListBackgroundAndSeparators() {
        return true;
    }
}

