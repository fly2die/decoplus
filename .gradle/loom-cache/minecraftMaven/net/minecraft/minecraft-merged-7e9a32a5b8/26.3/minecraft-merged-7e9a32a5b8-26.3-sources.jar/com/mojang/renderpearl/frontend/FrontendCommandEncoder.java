/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.frontend;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.logging.LogUtils;
import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.api.buffers.TransientMemory;
import com.mojang.renderpearl.api.commands.CommandEncoder;
import com.mojang.renderpearl.api.commands.GpuFence;
import com.mojang.renderpearl.api.commands.GpuQueryPool;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.commands.RenderPassDescriptor;
import com.mojang.renderpearl.api.textures.GpuTexture;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.api.CommandEncoderBackend;
import com.mojang.renderpearl.backend.api.GpuDeviceBackend;
import com.mojang.renderpearl.frontend.FrontendRenderPass;
import com.mojang.renderpearl.frontend.TracyGpuProfiler;
import java.nio.ByteBuffer;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.ApiStatus;
import org.joml.Vector4fc;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

@Environment(value=EnvType.CLIENT)
public class FrontendCommandEncoder
implements CommandEncoder {
    private static final Logger LOGGER = LogUtils.getLogger();
    private final GpuDeviceBackend device;
    private final CommandEncoderBackend backend;
    private boolean isInRenderPass;
    private final @Nullable TracyGpuProfiler profiler;

    public FrontendCommandEncoder(@Nullable TracyGpuProfiler profiler, GpuDeviceBackend device, CommandEncoderBackend backend) {
        this.profiler = profiler;
        this.device = device;
        this.backend = backend;
    }

    @ApiStatus.Internal
    public CommandEncoderBackend backend() {
        return this.backend;
    }

    @Override
    public void submit() {
        this.backend.submit();
        if (this.profiler != null) {
            this.profiler.endFrame();
        }
    }

    @Override
    public TransientMemory transientMemory() {
        return this.backend.transientMemory();
    }

    @ApiStatus.Internal
    public boolean isInRenderPass() {
        return this.isInRenderPass;
    }

    @Override
    public RenderPass createRenderPass(Supplier<String> label, GpuTextureView colorTexture, Optional<Vector4fc> clearColor) {
        return this.createRenderPass(label, colorTexture, clearColor, null, OptionalDouble.empty());
    }

    @Override
    public RenderPass createRenderPass(Supplier<String> label, GpuTextureView colorTexture, Optional<Vector4fc> clearColor, @Nullable GpuTextureView depthTexture, OptionalDouble clearDepth) {
        return this.createRenderPass(label, colorTexture, clearColor, depthTexture, clearDepth, new RenderPass.RenderArea(0, 0, colorTexture.getWidth(0), colorTexture.getHeight(0)));
    }

    @Override
    public RenderPass createRenderPass(Supplier<String> label, GpuTextureView colorTexture, Optional<Vector4fc> clearColor, @Nullable GpuTextureView depthTexture, OptionalDouble clearDepth, RenderPass.RenderArea renderArea) {
        RenderPassDescriptor.Builder descriptor = RenderPassDescriptor.builder(label).withColorAttachment(colorTexture, clearColor);
        if (depthTexture != null) {
            descriptor.withDepthAttachment(depthTexture, clearDepth);
        }
        descriptor.withRenderArea(renderArea);
        return this.createRenderPass(descriptor.build());
    }

    @Override
    public RenderPass createRenderPass(RenderPassDescriptor descriptor) {
        int attachmentHeight;
        int attachmentWidth;
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before creating a new one!");
        }
        int maxColorAttachments = this.device.getDeviceInfo().limits().maxColorAttachments();
        int colorAttachmentCount = descriptor.colorAttachments().size();
        if (colorAttachmentCount > maxColorAttachments) {
            throw new IllegalStateException("Render pass created with " + colorAttachmentCount + " color attachments but device only supports " + maxColorAttachments);
        }
        int totalAttachments = colorAttachmentCount + (descriptor.depthAttachment() != null ? 1 : 0);
        if (totalAttachments == 0) {
            throw new IllegalArgumentException("At least one attachment (depth or color) must be specified");
        }
        if (colorAttachmentCount != 0) {
            RenderPassDescriptor.Attachment<Optional<Vector4fc>> firstAttachment = descriptor.colorAttachments().getFirst();
            assert (firstAttachment != null);
            attachmentWidth = firstAttachment.textureView().getWidth(0);
            attachmentHeight = firstAttachment.textureView().getHeight(0);
        } else {
            attachmentWidth = descriptor.depthAttachment().textureView().getWidth(0);
            attachmentHeight = descriptor.depthAttachment().textureView().getHeight(0);
        }
        RenderPass.RenderArea renderArea = descriptor.renderArea();
        if (renderArea.x() < 0 || renderArea.y() < 0 || renderArea.x() + renderArea.width() > attachmentWidth || renderArea.y() + renderArea.height() > attachmentHeight) {
            throw new IllegalArgumentException("RenderPass render area " + String.valueOf(renderArea) + " is out of bounds for texture of " + attachmentWidth + "x" + attachmentHeight);
        }
        for (int i = 0; i < colorAttachmentCount; ++i) {
            RenderPassDescriptor.Attachment<Optional<Vector4fc>> colorAttachment = descriptor.colorAttachments().get(i);
            if (colorAttachment == null) continue;
            GpuTextureView colorTexture = colorAttachment.textureView();
            if (colorTexture.isClosed()) {
                throw new IllegalStateException("Color texture " + i + " is closed");
            }
            if ((colorTexture.texture().usage() & 8) == 0) {
                throw new IllegalStateException("Color texture " + i + " must have USAGE_RENDER_ATTACHMENT");
            }
            if (colorTexture.texture().getDepthOrLayers() > 1) {
                throw new UnsupportedOperationException("Color texture " + i + ": Textures with multiple depths or layers are not yet supported as an attachment");
            }
            if (colorTexture.getWidth(0) == attachmentWidth && colorTexture.getHeight(0) == attachmentHeight) continue;
            throw new IllegalArgumentException("Color texture " + i + ": size does not match expected attachment size. Is " + colorTexture.getWidth(0) + "x" + colorTexture.getHeight(0) + " expected " + attachmentWidth + "x" + attachmentHeight);
        }
        if (descriptor.depthAttachment() != null) {
            GpuTextureView depthTexture = descriptor.depthAttachment().textureView();
            if (depthTexture.isClosed()) {
                throw new IllegalStateException("Depth texture is closed");
            }
            if ((depthTexture.texture().usage() & 8) == 0) {
                throw new IllegalStateException("Depth texture must have USAGE_RENDER_ATTACHMENT");
            }
            if (depthTexture.texture().getDepthOrLayers() > 1) {
                throw new UnsupportedOperationException("Depth texture: Textures with multiple depths or layers are not yet supported as an attachment");
            }
            if (depthTexture.getWidth(0) != attachmentWidth || depthTexture.getHeight(0) != attachmentHeight) {
                throw new IllegalArgumentException("Depth texture: size does not match expected attachment size. Is " + depthTexture.getWidth(0) + "x" + depthTexture.getHeight(0) + " expected " + attachmentWidth + "x" + attachmentHeight);
            }
        }
        this.isInRenderPass = true;
        if (this.profiler != null) {
            this.profiler.pushZone(this, descriptor.label().get());
        }
        return new FrontendRenderPass(this.backend.createRenderPass(descriptor), this.device, descriptor.colorAttachments(), descriptor.depthAttachment() != null, this::submitRenderPass, renderArea);
    }

    protected void submitRenderPass() {
        if (!this.isInRenderPass) {
            throw new IllegalStateException("Can't submit a render pass if one isn't open");
        }
        this.isInRenderPass = false;
        this.backend.submitRenderPass();
        if (this.profiler != null) {
            this.profiler.popZone(this);
        }
    }

    @Override
    public void clearColorTexture(GpuTexture colorTexture, Vector4fc clearColor) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before creating a new one!");
        }
        this.verifyColorTexture(colorTexture);
        this.backend.clearColorTexture(colorTexture, clearColor);
    }

    @Override
    public void clearColorAndDepthTextures(GpuTexture colorTexture, Vector4fc clearColor, GpuTexture depthTexture, double clearDepth) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before creating a new one!");
        }
        this.verifyColorTexture(colorTexture);
        this.verifyDepthTexture(depthTexture);
        if (colorTexture.getMipLevels() != depthTexture.getMipLevels()) {
            throw new IllegalArgumentException("Both textures must have the same mip count");
        }
        this.backend.clearColorAndDepthTextures(colorTexture, clearColor, depthTexture, clearDepth);
    }

    @Override
    public void clearColorAndDepthTextures(GpuTexture colorTexture, Vector4fc clearColor, GpuTexture depthTexture, double clearDepth, int regionX, int regionY, int regionWidth, int regionHeight, int mipLevel) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before creating a new one!");
        }
        this.verifyColorTexture(colorTexture);
        this.verifyDepthTexture(depthTexture);
        if (colorTexture.getMipLevels() != depthTexture.getMipLevels()) {
            throw new IllegalArgumentException("Both textures must have the same mip count");
        }
        this.verifyRegion(colorTexture, regionX, regionY, regionWidth, regionHeight, mipLevel);
        this.backend.clearColorAndDepthTextures(colorTexture, clearColor, depthTexture, clearDepth, regionX, regionY, regionWidth, regionHeight, mipLevel);
    }

    @Override
    public void clearDepthTexture(GpuTexture depthTexture, double clearDepth) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before creating a new one!");
        }
        this.verifyDepthTexture(depthTexture);
        this.backend.clearDepthTexture(depthTexture, clearDepth);
    }

    @Override
    public void writeToBuffer(GpuBufferSlice destination, ByteBuffer data) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before performing additional commands");
        }
        GpuBuffer buffer = destination.buffer();
        if (buffer.isClosed()) {
            throw new IllegalStateException("Buffer already closed");
        }
        if ((buffer.usage() & 8) == 0) {
            throw new IllegalStateException("Buffer needs USAGE_COPY_DST to be a destination for a copy");
        }
        int length = data.remaining();
        if ((long)length > destination.length()) {
            throw new IllegalArgumentException("Cannot write more data than the slice allows (attempting to write " + length + " bytes into a slice of length " + destination.length() + ")");
        }
        if (destination.length() + destination.offset() > buffer.size()) {
            throw new IllegalArgumentException("Cannot write more data than this buffer can hold (attempting to write " + length + " bytes at offset " + destination.offset() + " to " + buffer.size() + " size buffer)");
        }
        this.backend.writeToBuffer(destination, data);
    }

    @Override
    public void copyToBuffer(GpuBufferSlice source, GpuBufferSlice target) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before performing additional commands");
        }
        GpuBuffer sourceBuffer = source.buffer();
        if (sourceBuffer.isClosed()) {
            throw new IllegalStateException("Source buffer already closed");
        }
        if ((sourceBuffer.usage() & 0x10) == 0) {
            throw new IllegalStateException("Source buffer needs USAGE_COPY_SRC to be a source for a copy");
        }
        GpuBuffer targetBuffer = target.buffer();
        if (targetBuffer.isClosed()) {
            throw new IllegalStateException("Target buffer already closed");
        }
        if ((targetBuffer.usage() & 8) == 0) {
            throw new IllegalStateException("Target buffer needs USAGE_COPY_DST to be a destination for a copy");
        }
        if (source.length() != target.length()) {
            throw new IllegalArgumentException("Cannot copy from slice of size " + source.length() + " to slice of size " + target.length() + ", they must be equal");
        }
        if (source.offset() + source.length() > sourceBuffer.size()) {
            throw new IllegalArgumentException("Cannot copy more data than the source buffer holds (attempting to copy " + source.length() + " bytes at offset " + source.offset() + " from " + sourceBuffer.size() + " size buffer)");
        }
        if (target.offset() + target.length() > targetBuffer.size()) {
            throw new IllegalArgumentException("Cannot copy more data than the target buffer can hold (attempting to copy " + target.length() + " bytes at offset " + target.offset() + " to " + targetBuffer.size() + " size buffer)");
        }
        this.backend.copyToBuffer(source, target);
    }

    @Override
    public void writeToTexture(GpuTexture destination, NativeImage source) {
        int width = destination.getWidth(0);
        int height = destination.getHeight(0);
        if (source.getWidth() != width || source.getHeight() != height) {
            throw new IllegalArgumentException("Cannot replace texture of size " + width + "x" + height + " with image of size " + source.getWidth() + "x" + source.getHeight());
        }
        this.writeToTexture(destination, source, 0, 0, 0, 0);
    }

    @Override
    public void writeToTexture(GpuTexture destination, NativeImage source, int mipLevel, int depthOrLayer, int destX, int destY) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before performing additional commands");
        }
        if (destination.getFormat().componentType() != GpuFormat.ComponentType.UNORM_8) {
            throw new IllegalArgumentException("Destination texture for NativeImage writes must have component type of UNORM_8");
        }
        if (destination.getFormat().componentCount() != source.format().components()) {
            throw new IllegalArgumentException("Destination(" + String.valueOf((Object)destination.getFormat()) + ") texture for NativeImage(" + String.valueOf((Object)source.format()) + ") write must have channel count matching source");
        }
        if (mipLevel < 0 || mipLevel >= destination.getMipLevels()) {
            throw new IllegalArgumentException("Invalid mipLevel " + mipLevel + ", must be >= 0 and < " + destination.getMipLevels());
        }
        if (destX + source.getWidth() > destination.getWidth(mipLevel) || destY + source.getHeight() > destination.getHeight(mipLevel)) {
            throw new IllegalArgumentException("Dest texture (" + source.getWidth() + "x" + source.getHeight() + ") is not large enough to write a rectangle of " + source.getWidth() + "x" + source.getHeight() + " at " + destX + "x" + destY + " (at mip level " + mipLevel + ")");
        }
        if (destination.isClosed()) {
            throw new IllegalStateException("Destination texture is closed");
        }
        if ((destination.usage() & 1) == 0) {
            throw new IllegalStateException("Color texture must have USAGE_COPY_DST to be a destination for a write");
        }
        if (depthOrLayer >= destination.getDepthOrLayers()) {
            throw new UnsupportedOperationException("Depth or layer is out of range, must be >= 0 and < " + destination.getDepthOrLayers());
        }
        this.writeToTexture(destination, source.getPixelBytes(), mipLevel, depthOrLayer, destX, destY, source.getWidth(), source.getHeight());
    }

    @Override
    public void writeToTexture(GpuTexture destination, ByteBuffer source, int mipLevel, int depthOrLayer, int destX, int destY, int width, int height) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before performing additional commands");
        }
        if (mipLevel < 0 || mipLevel >= destination.getMipLevels()) {
            throw new IllegalArgumentException("Invalid mipLevel, must be >= 0 and < " + destination.getMipLevels());
        }
        if (width * height * destination.getFormat().blockSize() > source.remaining()) {
            throw new IllegalArgumentException("Copy would overrun the source buffer (remaining length of " + source.remaining() + ", but copy is " + width + "x" + height + " of format " + String.valueOf((Object)destination.getFormat()) + ")");
        }
        if (destX + width > destination.getWidth(mipLevel) || destY + height > destination.getHeight(mipLevel)) {
            throw new IllegalArgumentException("Dest texture (" + destination.getWidth(mipLevel) + "x" + destination.getHeight(mipLevel) + ") is not large enough to write a rectangle of " + width + "x" + height + " at " + destX + "x" + destY);
        }
        if (destination.isClosed()) {
            throw new IllegalStateException("Destination texture is closed");
        }
        if ((destination.usage() & 1) == 0) {
            throw new IllegalStateException("Color texture must have USAGE_COPY_DST to be a destination for a write");
        }
        if (depthOrLayer >= destination.getDepthOrLayers()) {
            throw new UnsupportedOperationException("Depth or layer is out of range, must be >= 0 and < " + destination.getDepthOrLayers());
        }
        this.backend.writeToTexture(destination, source, mipLevel, depthOrLayer, destX, destY, width, height);
    }

    @Override
    public void copyBufferToTexture(GpuBufferSlice source, int sourceX, int sourceY, int sourceWidth, int sourceHeight, GpuTexture destination, int destinationX, int destinationY, int copyWidth, int copyHeight, int mipLevel, int arrayLayer) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before performing additional commands");
        }
        if (mipLevel < 0 || mipLevel >= destination.getMipLevels()) {
            throw new IllegalArgumentException("Invalid mipLevel, must be >= 0 and < " + destination.getMipLevels());
        }
        if (sourceX + copyWidth > sourceWidth || sourceY + copyHeight > sourceHeight) {
            throw new IllegalArgumentException("Copy source (" + sourceWidth + "x" + sourceHeight + ") is not large enough to read a rectangle of " + copyWidth + "x" + copyHeight + " from " + sourceX + "x" + sourceY);
        }
        if ((long)sourceWidth * (long)copyHeight * (long)destination.getFormat().blockSize() > source.length()) {
            throw new IllegalArgumentException("Copy would overrun the source buffer (remaining length of " + source.length() + ", but copy is " + copyWidth + "x" + copyHeight + " of format " + String.valueOf((Object)destination.getFormat()) + ")");
        }
        if (destinationX + copyWidth > destination.getWidth(mipLevel) || destinationY + copyHeight > destination.getHeight(mipLevel)) {
            throw new IllegalArgumentException("Dest texture (" + destination.getWidth(mipLevel) + "x" + destination.getHeight(mipLevel) + ") is not large enough to write a rectangle of " + copyWidth + "x" + copyHeight + " at " + destinationX + "x" + destinationY);
        }
        if (source.buffer().isClosed()) {
            throw new IllegalStateException("Source buffer is closed");
        }
        if ((source.buffer().usage() & 0x10) == 0) {
            throw new IllegalStateException("Source buffer must have USAGE_COPY_SRC to be a source for a read");
        }
        if (destination.isClosed()) {
            throw new IllegalStateException("Destination texture is closed");
        }
        if ((destination.usage() & 1) == 0) {
            throw new IllegalStateException("Color texture must have USAGE_COPY_DST to be a destination for a write");
        }
        if (arrayLayer >= destination.getDepthOrLayers()) {
            throw new UnsupportedOperationException("Depth or layer is out of range, must be >= 0 and < " + destination.getDepthOrLayers());
        }
        this.backend.copyBufferToTexture(source, sourceX, sourceY, sourceWidth, sourceHeight, destination, destinationX, destinationY, copyWidth, copyHeight, mipLevel, arrayLayer);
    }

    @Override
    public void copyTextureToBuffer(GpuTexture source, GpuBuffer destination, long offset, Runnable callback, int mipLevel) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before performing additional commands");
        }
        this.backend.copyTextureToBuffer(source, destination, offset, callback, mipLevel);
    }

    @Override
    public void copyTextureToBuffer(GpuTexture source, GpuBuffer destination, long offset, Runnable callback, int mipLevel, int x, int y, int width, int height) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before performing additional commands");
        }
        if (mipLevel < 0 || mipLevel >= source.getMipLevels()) {
            throw new IllegalArgumentException("Invalid mipLevel " + mipLevel + ", must be >= 0 and < " + source.getMipLevels());
        }
        if ((long)width * (long)height * (long)source.getFormat().blockSize() + offset > destination.size()) {
            throw new IllegalArgumentException("Buffer of size " + destination.size() + " is not large enough to hold " + width + "x" + height + " pixels (" + source.getFormat().blockSize() + " bytes each) starting from offset " + offset);
        }
        if ((source.usage() & 2) == 0) {
            throw new IllegalArgumentException("Texture needs USAGE_COPY_SRC to be a source for a copy");
        }
        if ((destination.usage() & 8) == 0) {
            throw new IllegalArgumentException("Buffer needs USAGE_COPY_DST to be a destination for a copy");
        }
        if (x + width > source.getWidth(mipLevel) || y + height > source.getHeight(mipLevel)) {
            throw new IllegalArgumentException("Copy source texture (" + source.getWidth(mipLevel) + "x" + source.getHeight(mipLevel) + ") is not large enough to read a rectangle of " + width + "x" + height + " from " + x + "," + y);
        }
        if (source.isClosed()) {
            throw new IllegalStateException("Source texture is closed");
        }
        if (destination.isClosed()) {
            throw new IllegalStateException("Destination buffer is closed");
        }
        if (source.getDepthOrLayers() > 1) {
            throw new UnsupportedOperationException("Textures with multiple depths or layers are not yet supported for copying");
        }
        this.backend.copyTextureToBuffer(source, destination, offset, callback, mipLevel, x, y, width, height);
    }

    @Override
    public void copyTextureToTexture(GpuTexture source, GpuTexture destination, int mipLevel, int destX, int destY, int sourceX, int sourceY, int width, int height) {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before performing additional commands");
        }
        if (mipLevel < 0 || mipLevel >= source.getMipLevels() || mipLevel >= destination.getMipLevels()) {
            throw new IllegalArgumentException("Invalid mipLevel " + mipLevel + ", must be >= 0 and < " + source.getMipLevels() + " and < " + destination.getMipLevels());
        }
        if (destX + width > destination.getWidth(mipLevel) || destY + height > destination.getHeight(mipLevel)) {
            throw new IllegalArgumentException("Dest texture (" + destination.getWidth(mipLevel) + "x" + destination.getHeight(mipLevel) + ") is not large enough to write a rectangle of " + width + "x" + height + " at " + destX + "x" + destY);
        }
        if (sourceX + width > source.getWidth(mipLevel) || sourceY + height > source.getHeight(mipLevel)) {
            throw new IllegalArgumentException("Source texture (" + source.getWidth(mipLevel) + "x" + source.getHeight(mipLevel) + ") is not large enough to read a rectangle of " + width + "x" + height + " at " + sourceX + "x" + sourceY);
        }
        if (source.isClosed()) {
            throw new IllegalStateException("Source texture is closed");
        }
        if (destination.isClosed()) {
            throw new IllegalStateException("Destination texture is closed");
        }
        if ((source.usage() & 2) == 0) {
            throw new IllegalArgumentException("Texture needs USAGE_COPY_SRC to be a source for a copy");
        }
        if ((destination.usage() & 1) == 0) {
            throw new IllegalArgumentException("Texture needs USAGE_COPY_DST to be a destination for a copy");
        }
        if (source.getDepthOrLayers() > 1) {
            throw new UnsupportedOperationException("Textures with multiple depths or layers are not yet supported for copying");
        }
        if (destination.getDepthOrLayers() > 1) {
            throw new UnsupportedOperationException("Textures with multiple depths or layers are not yet supported for copying");
        }
        this.backend.copyTextureToTexture(source, destination, mipLevel, destX, destY, sourceX, sourceY, width, height);
    }

    @Override
    public GpuFence createFence() {
        if (this.isInRenderPass) {
            throw new IllegalStateException("Close the existing render pass before performing additional commands");
        }
        return this.backend.createFence();
    }

    @Override
    public void writeTimestamp(GpuQueryPool pool, int index) {
        if (index < 0 || index > pool.size()) {
            throw new IllegalStateException("Index " + index + " is out of range for query pool of size " + pool.size());
        }
        this.backend.writeTimestamp(pool, index);
    }

    private void verifyColorTexture(GpuTexture colorTexture) {
        if (!colorTexture.getFormat().hasColorAspect()) {
            throw new IllegalStateException("Trying to clear a non-color texture as color");
        }
        if (colorTexture.isClosed()) {
            throw new IllegalStateException("Color texture is closed");
        }
        if ((colorTexture.usage() & 8) == 0) {
            throw new IllegalStateException("Color texture must have USAGE_RENDER_ATTACHMENT");
        }
        if ((colorTexture.usage() & 1) == 0) {
            throw new IllegalStateException("Color texture must have USAGE_COPY_DST");
        }
        if (colorTexture.getDepthOrLayers() > 1) {
            throw new UnsupportedOperationException("Clearing a texture with multiple layers or depths is not yet supported");
        }
    }

    private void verifyDepthTexture(GpuTexture depthTexture) {
        if (!depthTexture.getFormat().hasDepthAspect()) {
            throw new IllegalStateException("Trying to clear a non-depth texture as depth");
        }
        if (depthTexture.isClosed()) {
            throw new IllegalStateException("Depth texture is closed");
        }
        if ((depthTexture.usage() & 8) == 0) {
            throw new IllegalStateException("Depth texture must have USAGE_RENDER_ATTACHMENT");
        }
        if ((depthTexture.usage() & 1) == 0) {
            throw new IllegalStateException("Depth texture must have USAGE_COPY_DST");
        }
        if (depthTexture.getDepthOrLayers() > 1) {
            throw new UnsupportedOperationException("Clearing a texture with multiple layers or depths is not yet supported");
        }
    }

    private void verifyRegion(GpuTexture colorTexture, int regionX, int regionY, int regionWidth, int regionHeight, int mipLevel) {
        if (mipLevel >= colorTexture.getMipLevels()) {
            throw new IllegalArgumentException("Mip level " + mipLevel + " out of range for texture with " + colorTexture.getMipLevels() + " mips");
        }
        if (regionX < 0 || regionX >= colorTexture.getWidth(mipLevel)) {
            throw new IllegalArgumentException("regionX should not be outside of the texture");
        }
        if (regionY < 0 || regionY >= colorTexture.getHeight(mipLevel)) {
            throw new IllegalArgumentException("regionY should not be outside of the texture");
        }
        if (regionWidth <= 0) {
            throw new IllegalArgumentException("regionWidth should be greater than 0");
        }
        if (regionX + regionWidth > colorTexture.getWidth(mipLevel)) {
            throw new IllegalArgumentException("regionWidth + regionX should be less than the texture width");
        }
        if (regionHeight <= 0) {
            throw new IllegalArgumentException("regionHeight should be greater than 0");
        }
        if (regionY + regionHeight > colorTexture.getHeight(mipLevel)) {
            throw new IllegalArgumentException("regionWidth + regionX should be less than the texture height");
        }
    }
}

