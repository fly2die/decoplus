/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.backend.vulkan;

import com.mojang.renderpearl.backend.vulkan.VulkanDevice;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import it.unimi.dsi.fastutil.objects.ReferenceArrayList;
import java.util.List;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.KHRSynchronization2;
import org.lwjgl.vulkan.VK12;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkCommandBufferSubmitInfo;
import org.lwjgl.vulkan.VkQueue;
import org.lwjgl.vulkan.VkSemaphoreSubmitInfo;
import org.lwjgl.vulkan.VkSubmitInfo2;

@Environment(value=EnvType.CLIENT)
public record VulkanQueue(VkQueue vkQueue, int queueFamilyIndex) {
    public VulkanQueue(VulkanDevice device, int queueFamilyIndex, int queueIndex) {
        this(new VkQueue(VulkanQueue.fetchVkQueue(device, queueFamilyIndex, queueIndex), device.vkDevice()), queueFamilyIndex);
    }

    private static long fetchVkQueue(VulkanDevice device, int queueFamilyIndex, int queueIndex) {
        try (MemoryStack stack = MemoryStack.stackPush();){
            PointerBuffer queueHandlePtr = stack.callocPointer(1);
            VK12.vkGetDeviceQueue(device.vkDevice(), queueFamilyIndex, queueIndex, queueHandlePtr);
            long l = queueHandlePtr.get(0);
            return l;
        }
    }

    public Submission beginSubmit() {
        return new Submission(this);
    }

    public void waitIdle() {
        VK12.vkQueueWaitIdle(this.vkQueue);
    }

    @Environment(value=EnvType.CLIENT)
    public class Submission
    implements UncheckedAutoCloseable {
        private boolean closed;
        private final ReferenceArrayList<SubmitStage> stages;
        final /* synthetic */ VulkanQueue this$0;

        private Submission(VulkanQueue this$0) {
            VulkanQueue vulkanQueue = this$0;
            Objects.requireNonNull(vulkanQueue);
            this.this$0 = vulkanQueue;
            this.closed = false;
            this.stages = new ReferenceArrayList();
            this.stages.add(new SubmitStage());
        }

        public void waitSemaphore(long semaphore, long value, long stageMask) {
            if (this.closed) {
                throw new IllegalStateException("Attempt to use closed Submission");
            }
            if (!((SubmitStage)this.stages.top()).commandBuffers.isEmpty() || !((SubmitStage)this.stages.top()).signals.isEmpty()) {
                this.stages.add(new SubmitStage());
            }
            ((SubmitStage)this.stages.top()).waits.add(new SemaphoreOp(semaphore, value, stageMask));
        }

        public void executeCommands(VkCommandBuffer commandBuffer) {
            if (this.closed) {
                throw new IllegalStateException("Attempt to use closed Submission");
            }
            if (!((SubmitStage)this.stages.top()).signals.isEmpty()) {
                this.stages.add(new SubmitStage());
            }
            ((SubmitStage)this.stages.top()).commandBuffers.add(commandBuffer);
        }

        public void signalSemaphore(long semaphore, long value, long stageMask) {
            if (this.closed) {
                throw new IllegalStateException("Attempt to use closed Submission");
            }
            ((SubmitStage)this.stages.top()).signals.add(new SemaphoreOp(semaphore, value, stageMask));
        }

        @Override
        public void close() {
            try (MemoryStack stack = MemoryStack.stackPush();){
                VkSubmitInfo2.Buffer submits = VkSubmitInfo2.calloc(this.stages.size(), stack);
                for (int i = 0; i < this.stages.size(); ++i) {
                    int j;
                    SubmitStage stage = this.stages.get(i);
                    ((VkSubmitInfo2.Buffer)submits.position(i)).sType$Default();
                    if (!stage.waits.isEmpty()) {
                        VkSemaphoreSubmitInfo.Buffer waits = VkSemaphoreSubmitInfo.calloc(stage.waits.size(), stack);
                        submits.pWaitSemaphoreInfos(waits);
                        for (j = 0; j < stage.waits.size(); ++j) {
                            SemaphoreOp wait = stage.waits.get(j);
                            ((VkSemaphoreSubmitInfo.Buffer)waits.position(j)).sType$Default();
                            waits.semaphore(wait.vkSemaphore);
                            waits.value(wait.value);
                            waits.stageMask(wait.stageMask);
                        }
                    }
                    if (!stage.commandBuffers.isEmpty()) {
                        VkCommandBufferSubmitInfo.Buffer buffers = VkCommandBufferSubmitInfo.calloc(stage.commandBuffers.size(), stack);
                        submits.pCommandBufferInfos(buffers);
                        for (j = 0; j < stage.commandBuffers.size(); ++j) {
                            VkCommandBuffer vkCommandBuffer = stage.commandBuffers.get(j);
                            ((VkCommandBufferSubmitInfo.Buffer)buffers.position(j)).sType$Default();
                            buffers.commandBuffer(vkCommandBuffer);
                        }
                    }
                    if (stage.signals.isEmpty()) continue;
                    VkSemaphoreSubmitInfo.Buffer signals = VkSemaphoreSubmitInfo.calloc(stage.signals.size(), stack);
                    submits.pSignalSemaphoreInfos(signals);
                    for (j = 0; j < stage.signals.size(); ++j) {
                        SemaphoreOp signal = stage.signals.get(j);
                        ((VkSemaphoreSubmitInfo.Buffer)signals.position(j)).sType$Default();
                        signals.semaphore(signal.vkSemaphore);
                        signals.value(signal.value);
                        signals.stageMask(signal.stageMask);
                    }
                }
                submits.position(0);
                KHRSynchronization2.vkQueueSubmit2KHR(this.this$0.vkQueue, submits, 0L);
                this.closed = true;
            }
        }

        @Environment(value=EnvType.CLIENT)
        private record SubmitStage(List<SemaphoreOp> waits, List<VkCommandBuffer> commandBuffers, List<SemaphoreOp> signals) {
            public SubmitStage() {
                this(new ReferenceArrayList<SemaphoreOp>(), new ReferenceArrayList<VkCommandBuffer>(), new ReferenceArrayList<SemaphoreOp>());
            }
        }

        @Environment(value=EnvType.CLIENT)
        private record SemaphoreOp(long vkSemaphore, long value, long stageMask) {
        }
    }
}

