/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.advancements.triggers;

import com.mojang.serialization.Codec;
import net.minecraft.advancements.CriterionTriggerInstance;
import net.minecraft.advancements.triggers.Criterion;

public interface CriterionTrigger<T extends CriterionTriggerInstance> {
    public Codec<T> codec();

    default public Criterion<T> createCriterion(T instance) {
        return new Criterion<T>(this, instance);
    }
}

