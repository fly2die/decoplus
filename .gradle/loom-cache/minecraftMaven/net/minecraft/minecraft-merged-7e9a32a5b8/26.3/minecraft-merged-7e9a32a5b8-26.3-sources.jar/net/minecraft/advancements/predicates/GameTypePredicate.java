/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.advancements.predicates;

import com.mojang.serialization.Codec;
import java.util.Arrays;
import java.util.List;
import net.minecraft.world.level.GameType;

public record GameTypePredicate(List<GameType> types) {
    public static final GameTypePredicate ANY = GameTypePredicate.of(GameType.values());
    public static final GameTypePredicate SURVIVAL_LIKE = GameTypePredicate.of(GameType.SURVIVAL, GameType.ADVENTURE);
    public static final Codec<GameTypePredicate> CODEC = GameType.CODEC.listOf().xmap(GameTypePredicate::new, GameTypePredicate::types);

    public static GameTypePredicate of(GameType ... types) {
        return new GameTypePredicate(Arrays.stream(types).toList());
    }

    public boolean matches(GameType type) {
        return this.types.contains(type);
    }
}

