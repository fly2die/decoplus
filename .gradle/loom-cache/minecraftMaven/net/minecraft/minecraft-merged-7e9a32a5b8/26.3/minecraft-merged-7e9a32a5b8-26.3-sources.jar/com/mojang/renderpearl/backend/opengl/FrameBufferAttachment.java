/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.backend.opengl;

import com.mojang.renderpearl.backend.opengl.FrameBufferCache;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface FrameBufferAttachment {
    public int glId();

    public int fboMipLevel();

    public void addAssociatedFbo(FrameBufferCache.CacheKey var1);

    public void removeAssociatedFbo(FrameBufferCache.CacheKey var1);
}

