/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.platform;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.server.packs.PackMetadataResources;
import net.minecraft.server.packs.resources.IoSupplier;
import org.apache.commons.lang3.ArrayUtils;

@Environment(value=EnvType.CLIENT)
public enum IconSet {
    RELEASE("icons"),
    SNAPSHOT("icons", "snapshot");

    private final String[] path;

    private IconSet(String ... path) {
        this.path = path;
    }

    public List<IoSupplier<InputStream>> getStandardIcons(PackMetadataResources resources) throws IOException {
        return List.of(this.getFile(resources, "icon_256x256.png"), this.getFile(resources, "icon_128x128.png"), this.getFile(resources, "icon_48x48.png"), this.getFile(resources, "icon_32x32.png"), this.getFile(resources, "icon_16x16.png"));
    }

    private IoSupplier<InputStream> getFile(PackMetadataResources resources, String fileName) throws IOException {
        CharSequence[] fullPath = ArrayUtils.add(this.path, fileName);
        IoSupplier<InputStream> resource = resources.getRootResource((String[])fullPath);
        if (resource == null) {
            throw new FileNotFoundException(String.join((CharSequence)"/", fullPath));
        }
        return resource;
    }
}

