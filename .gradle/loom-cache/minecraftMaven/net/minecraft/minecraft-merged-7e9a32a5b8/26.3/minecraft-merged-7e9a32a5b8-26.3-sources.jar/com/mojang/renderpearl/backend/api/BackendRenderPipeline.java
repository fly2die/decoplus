/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.renderpearl.backend.api;

import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.pipeline.BindGroupLayout;
import com.mojang.renderpearl.api.pipeline.ColorTargetState;
import com.mojang.renderpearl.api.pipeline.DepthStencilState;
import com.mojang.renderpearl.api.pipeline.PolygonMode;
import com.mojang.renderpearl.api.pipeline.PrimitiveTopology;
import com.mojang.renderpearl.backend.api.SpvModule;
import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public interface BackendRenderPipeline
extends UncheckedAutoCloseable {
    public boolean isClosed();

    @FunctionalInterface
    @Environment(value=EnvType.CLIENT)
    public static interface Pending {
        public static final Pending NULL = () -> null;

        public @Nullable BackendRenderPipeline finishCompile();
    }

    @Environment(value=EnvType.CLIENT)
    public record CreateInfo(String name, List<Shader> shaders, List<VertexBuffer> vertexBuffers, List<AttribBinding> attribBindings, List<BindGroupLayout.UniformDescription> uniforms, int pushConstantsSize, @Nullable DepthStencilState depthStencilState, PolygonMode polygonMode, boolean cull, List<@Nullable ColorTargetState> colorTargetStates, PrimitiveTopology primitiveTopology) {

        @Environment(value=EnvType.CLIENT)
        public record AttribBinding(int bufferSlot, int location, int offset, GpuFormat format) {
        }

        @Environment(value=EnvType.CLIENT)
        public record VertexBuffer(int bufferSlot, int stride, int stepRate) {
        }

        @Environment(value=EnvType.CLIENT)
        public record Shader(String name, String entryPoint, SpvModule module) {
        }
    }
}

