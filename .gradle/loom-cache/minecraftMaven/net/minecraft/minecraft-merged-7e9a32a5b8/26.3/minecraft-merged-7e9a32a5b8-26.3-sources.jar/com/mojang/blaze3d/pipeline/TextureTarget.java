/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package com.mojang.blaze3d.pipeline;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.GpuFormat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public class TextureTarget
extends RenderTarget {
    public TextureTarget(@Nullable String label, int width, int height, @Nullable GpuFormat colorFormat, @Nullable GpuFormat depthFormat) {
        super(label, colorFormat, depthFormat);
        RenderSystem.assertOnRenderThread();
        this.resize(width, height);
    }
}

